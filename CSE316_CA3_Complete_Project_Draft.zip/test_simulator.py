import unittest
from main import simulate_fifo, simulate_lru, simulate_optimal, parse_reference_string


class PageReplacementTests(unittest.TestCase):
    def setUp(self):
        self.pages = [1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5]

    def test_fifo_known_fault_count(self):
        result = simulate_fifo(self.pages, 3)
        self.assertEqual(result["faults"], 9)
        self.assertEqual(result["hits"], 3)

    def test_lru_known_fault_count(self):
        result = simulate_lru(self.pages, 3)
        self.assertEqual(result["faults"], 10)
        self.assertEqual(result["hits"], 2)

    def test_optimal_known_fault_count(self):
        result = simulate_optimal(self.pages, 3)
        self.assertEqual(result["faults"], 7)
        self.assertEqual(result["hits"], 5)

    def test_hits_plus_faults_equals_references(self):
        for algorithm in (simulate_fifo, simulate_lru, simulate_optimal):
            result = algorithm(self.pages, 3)
            self.assertEqual(result["hits"] + result["faults"], len(self.pages))

    def test_parse_commas_and_spaces(self):
        self.assertEqual(parse_reference_string("1, 2  3"), [1, 2, 3])

    def test_rejects_non_integer(self):
        with self.assertRaises(ValueError):
            parse_reference_string("1 a 3")

    def test_rejects_negative_page(self):
        with self.assertRaises(ValueError):
            parse_reference_string("1 -2 3")


if __name__ == "__main__":
    unittest.main()
