# CSE316 Project Report
## Efficient Page Replacement Algorithm Simulator

### 1. Abstract
This project implements a desktop simulator for three operating-system page replacement algorithms: First-In, First-Out (FIFO), Least Recently Used (LRU), and Optimal. The user enters a page-reference string and the number of available page frames. The application displays each reference, the frame contents after processing it, whether it was a hit or fault, and the replaced page. It also reports total hits, total faults, hit rate, and fault rate, and provides a comparison of all algorithms.

### 2. Problem Statement
When a process accesses a page that is not in main memory and all page frames are occupied, the operating system must choose a page to remove. Different replacement policies can produce different numbers of page faults. This simulator makes the policies observable and helps students compare their behavior on the same input.

### 3. Objectives
- Implement FIFO, LRU, and Optimal page replacement.
- Accept user-defined page-reference strings and frame counts.
- Show the frame state after every reference.
- Calculate page hits, page faults, hit rate, and fault rate.
- Compare the three algorithms using the same input.
- Provide input validation and a simple graphical interface.

### 4. Tools and Technologies
- Language: Python
- GUI: Tkinter and ttk
- Testing: Python `unittest`
- External dependencies: None

### 5. System Design
The program is separated conceptually into two parts:
1. **Simulation functions:** each algorithm receives a list of page references and a frame count and returns a sequence of steps plus hit/fault totals.
2. **Graphical interface:** collects inputs, calls the chosen algorithm, renders the step table, and displays summary metrics.

### 6. Algorithm Logic
**FIFO:** Maintain frames and a circular replacement pointer. On a miss, fill an empty frame first; once full, replace the frame at the pointer and advance the pointer.

**LRU:** Track the most recent access index for each page currently in memory. On a miss with full frames, replace the page with the smallest last-access index.

**Optimal:** Look ahead through the remaining reference string. Replace the resident page whose next access is farthest away; if it never appears again, replace it. This algorithm is mainly a theoretical comparison baseline.

### 7. Metrics
- **Page hit:** requested page is already in a frame.
- **Page fault:** requested page is not in a frame.
- **Hit rate:** `(page hits / total references) × 100`.
- **Fault rate:** `(page faults / total references) × 100`.

### 8. How to Run
1. Install Python 3 if it is not already installed.
2. Extract the ZIP file.
3. Open a terminal in the project folder.
4. Run `python main.py`.
5. Enter the page references and a frame count from 1 to 4.
6. Run one algorithm or compare all algorithms.

### 9. Testing
Automated tests check known page-fault totals, consistency between hits and faults, and invalid reference input. Run `python -m unittest test_simulator.py`.

### 10. Limitations
- The interface supports up to four frames so that the frame table remains readable.
- The simulator models page replacement only; it does not emulate a complete operating system or physical memory.
- Optimal uses future references and therefore cannot be implemented as a practical online policy without knowing the future.

### 11. Future Enhancements
- Support an arbitrary number of frames with a dynamically generated table.
- Add charts for fault-count comparisons.
- Export simulation results to CSV.
- Add additional policies such as LFU and Clock.

### 12. Conclusion
The project provides a visual and testable way to understand how FIFO, LRU, and Optimal respond to the same page-reference sequence. By displaying each frame transition and summarizing faults and hits, it supports practical learning of operating-system memory management.
