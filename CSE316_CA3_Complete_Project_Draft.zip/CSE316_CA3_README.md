# CSE316 — Efficient Page Replacement Algorithm Simulator

## Run
Use Python 3 and run `python main.py` (Windows: `py main.py`). No third-party packages are required.

## Test
Run `python -m unittest test_simulator.py`.

## Contents
- `main.py`: GUI and FIFO/LRU/Optimal algorithm functions
- `test_simulator.py`: automated unit tests
- `report.md`: concise report
- `CSE316_CA3_Complete_Report_Draft.docx`: expanded report with required headings and source appendix

## Before submission
- Fill in your real name, registration number, group members, repository name, and GitHub URL.
- The assignment requires at least 7 genuine GitHub revisions, meaningful commit messages, branches and merges. Add evidence from your actual repository; do not invent commits.
- Run the GUI on your own computer and capture screenshots if required.
- Review and understand the code. The assignment prohibits submitting AI-generated/copied code as your own.
- Add any presentation slides or other evidence your instructor requests.
