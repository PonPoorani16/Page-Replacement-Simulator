# CSE316 — Efficient Page Replacement Algorithm Simulator

A beginner-friendly Python desktop project that simulates and compares FIFO, LRU, and Optimal page replacement algorithms.

## Requirements
- Python 3.10 or later recommended
- Tkinter (included with most standard Python installations)
- No third-party packages required

## Run
1. Extract the project ZIP.
2. Open a terminal in this folder.
3. Run: `python main.py` (Windows may use `py main.py`).

## How to use
1. Enter page references separated by spaces or commas, for example `7 0 1 2 0 3 0 4 2 3 0 3 2`.
2. Enter a frame count from 1 to 4.
3. Select FIFO, LRU, or Optimal and click **Run simulation**.
4. Click **Compare all** to compare page-fault and page-hit counts for all three algorithms.
5. In the table, red rows indicate page faults and green rows indicate page hits.

## Algorithms
- **FIFO (First-In, First-Out):** replaces the page that has been in memory the longest.
- **LRU (Least Recently Used):** replaces the page that was accessed least recently.
- **Optimal:** replaces the page whose next use is farthest in the future (or which is never used again). It is a theoretical benchmark because future references are not known in a real operating system.

## Project structure
- `main.py` — algorithms and Tkinter graphical interface
- `report.md` — project report in Markdown
- `test_simulator.py` — automated unit tests for the algorithm functions

## Validation
Run the tests with: `python -m unittest test_simulator.py`
