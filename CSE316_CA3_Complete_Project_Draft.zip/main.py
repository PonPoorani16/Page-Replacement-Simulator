"""
CSE316 - Efficient Page Replacement Algorithm Simulator
Algorithms: FIFO, LRU, Optimal
Run: python main.py
Uses Python's built-in Tkinter; no external packages required.
"""
import tkinter as tk
from tkinter import ttk, messagebox


def parse_reference_string(raw):
    """Convert comma/space-separated page references to a list of integers."""
    cleaned = raw.replace(",", " ").strip()
    if not cleaned:
        raise ValueError("Enter a page reference string.")
    try:
        pages = [int(item) for item in cleaned.split()]
    except ValueError:
        raise ValueError("Page references must be integers separated by spaces or commas.")
    if any(page < 0 for page in pages):
        raise ValueError("Page references must be zero or positive integers.")
    return pages


def simulate_fifo(pages, frame_count):
    frames = []
    pointer = 0
    steps = []
    hits = faults = 0
    for page in pages:
        before = frames.copy()
        if page in frames:
            hits += 1
            status = "HIT"
            replaced = "-"
        else:
            faults += 1
            status = "FAULT"
            if len(frames) < frame_count:
                frames.append(page)
                replaced = "Empty slot"
            else:
                replaced = str(frames[pointer])
                frames[pointer] = page
                pointer = (pointer + 1) % frame_count
        steps.append({
            "page": page, "before": before, "frames": frames.copy(),
            "status": status, "replaced": replaced
        })
    return {"name": "FIFO", "steps": steps, "hits": hits, "faults": faults}


def simulate_lru(pages, frame_count):
    frames = []
    last_used = {}
    steps = []
    hits = faults = 0
    for index, page in enumerate(pages):
        before = frames.copy()
        if page in frames:
            hits += 1
            status = "HIT"
            replaced = "-"
        else:
            faults += 1
            status = "FAULT"
            if len(frames) < frame_count:
                frames.append(page)
                replaced = "Empty slot"
            else:
                least_recent_page = min(frames, key=lambda p: last_used[p])
                replaced = str(least_recent_page)
                frames[frames.index(least_recent_page)] = page
        last_used[page] = index
        steps.append({
            "page": page, "before": before, "frames": frames.copy(),
            "status": status, "replaced": replaced
        })
    return {"name": "LRU", "steps": steps, "hits": hits, "faults": faults}


def simulate_optimal(pages, frame_count):
    frames = []
    steps = []
    hits = faults = 0
    for index, page in enumerate(pages):
        before = frames.copy()
        if page in frames:
            hits += 1
            status = "HIT"
            replaced = "-"
        else:
            faults += 1
            status = "FAULT"
            if len(frames) < frame_count:
                frames.append(page)
                replaced = "Empty slot"
            else:
                future = pages[index + 1:]
                next_use = {}
                for frame_page in frames:
                    next_use[frame_page] = future.index(frame_page) if frame_page in future else float("inf")
                victim = max(frames, key=lambda p: next_use[p])
                replaced = str(victim)
                frames[frames.index(victim)] = page
        steps.append({
            "page": page, "before": before, "frames": frames.copy(),
            "status": status, "replaced": replaced
        })
    return {"name": "Optimal", "steps": steps, "hits": hits, "faults": faults}


ALGORITHMS = {
    "FIFO": simulate_fifo,
    "LRU": simulate_lru,
    "Optimal": simulate_optimal,
}


class PageReplacementApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CSE316 | Page Replacement Algorithm Simulator")
        self.root.geometry("1100x760")
        self.root.minsize(850, 600)
        self.root.configure(bg="#f3f6fb")
        self.current_result = None
        self._build_ui()

    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#f3f6fb")
        style.configure("TLabel", background="#f3f6fb", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 19, "bold"), foreground="#172554")
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#475569")
        style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=7)
        style.configure("Treeview", font=("Consolas", 10), rowheight=27)
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Page Replacement Algorithm Simulator", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="CSE316 • Compare FIFO, Least Recently Used (LRU), and Optimal page replacement",
            style="Sub.TLabel"
        ).pack(anchor="w", pady=(2, 16))

        controls = ttk.LabelFrame(outer, text="Simulation inputs", padding=12)
        controls.pack(fill="x", pady=(0, 12))

        ttk.Label(controls, text="Page reference string:").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.reference_var = tk.StringVar(value="7 0 1 2 0 3 0 4 2 3 0 3 2")
        self.reference_entry = ttk.Entry(controls, textvariable=self.reference_var, width=58)
        self.reference_entry.grid(row=0, column=1, sticky="ew", padx=(0, 14))

        ttk.Label(controls, text="Number of frames:").grid(row=0, column=2, sticky="w", padx=(0, 8))
        self.frames_var = tk.StringVar(value="3")
        self.frames_entry = ttk.Entry(controls, textvariable=self.frames_var, width=7)
        self.frames_entry.grid(row=0, column=3, sticky="w", padx=(0, 14))

        ttk.Label(controls, text="Algorithm:").grid(row=1, column=0, sticky="w", pady=(12, 0))
        self.algorithm_var = tk.StringVar(value="FIFO")
        self.algorithm_combo = ttk.Combobox(
            controls, textvariable=self.algorithm_var, values=list(ALGORITHMS.keys()),
            state="readonly", width=15
        )
        self.algorithm_combo.grid(row=1, column=1, sticky="w", pady=(12, 0))
        ttk.Button(controls, text="Run simulation", command=self.run_simulation).grid(
            row=1, column=2, sticky="w", pady=(12, 0)
        )
        ttk.Button(controls, text="Compare all", command=self.compare_all).grid(
            row=1, column=3, sticky="w", pady=(12, 0)
        )
        controls.columnconfigure(1, weight=1)

        summary = ttk.Frame(outer)
        summary.pack(fill="x", pady=(0, 12))
        self.faults_card = self._make_stat_card(summary, "Page faults", "—")
        self.hits_card = self._make_stat_card(summary, "Page hits", "—")
        self.hit_rate_card = self._make_stat_card(summary, "Hit rate", "—")
        self.fault_rate_card = self._make_stat_card(summary, "Fault rate", "—")

        results_frame = ttk.LabelFrame(outer, text="Step-by-step frame table", padding=8)
        results_frame.pack(fill="both", expand=True)
        columns = ("step", "page", "frame1", "frame2", "frame3", "frame4", "status", "replaced")
        self.tree = ttk.Treeview(results_frame, columns=columns, show="headings")
        headings = {
            "step": "Step", "page": "Page", "frame1": "Frame 1", "frame2": "Frame 2",
            "frame3": "Frame 3", "frame4": "Frame 4", "status": "Result", "replaced": "Replaced"
        }
        widths = {"step": 55, "page": 70, "frame1": 85, "frame2": 85, "frame3": 85,
                  "frame4": 85, "status": 100, "replaced": 110}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="center")
        self.tree.tag_configure("HIT", background="#dcfce7")
        self.tree.tag_configure("FAULT", background="#fee2e2")
        yscroll = ttk.Scrollbar(results_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(results_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        results_frame.rowconfigure(0, weight=1)
        results_frame.columnconfigure(0, weight=1)

        self.footer_var = tk.StringVar(value="Tip: use spaces or commas between page numbers.")
        ttk.Label(outer, textvariable=self.footer_var, style="Sub.TLabel").pack(anchor="w", pady=(10, 0))

    def _make_stat_card(self, parent, title, value):
        card = ttk.LabelFrame(parent, text=title, padding=(12, 8))
        card.pack(side="left", fill="x", expand=True, padx=(0, 8))
        value_label = ttk.Label(card, text=value, font=("Segoe UI", 16, "bold"), foreground="#1d4ed8")
        value_label.pack(anchor="w")
        return value_label

    def _read_inputs(self):
        pages = parse_reference_string(self.reference_var.get())
        try:
            frame_count = int(self.frames_var.get())
        except ValueError:
            raise ValueError("Number of frames must be a whole number.")
        if frame_count < 1:
            raise ValueError("Number of frames must be at least 1.")
        if frame_count > 4:
            raise ValueError("This interface displays up to 4 frames. Enter a value from 1 to 4.")
        return pages, frame_count

    def run_simulation(self):
        try:
            pages, frame_count = self._read_inputs()
        except ValueError as error:
            messagebox.showerror("Invalid input", str(error))
            return
        algorithm = self.algorithm_var.get()
        result = ALGORITHMS[algorithm](pages, frame_count)
        self.current_result = result
        self._display_result(result, frame_count)
        self.footer_var.set(f"Completed {algorithm} simulation for {len(pages)} page references.")

    def compare_all(self):
        try:
            pages, frame_count = self._read_inputs()
        except ValueError as error:
            messagebox.showerror("Invalid input", str(error))
            return
        results = [function(pages, frame_count) for function in ALGORITHMS.values()]
        best = min(results, key=lambda result: result["faults"])
        lines = []
        for result in results:
            lines.append(f'{result["name"]}: {result["faults"]} faults, {result["hits"]} hits')
        lines.append(f'\nFewest page faults for this input: {best["name"]}')
        messagebox.showinfo("Algorithm comparison", "\n".join(lines))
        selected = next(result for result in results if result["name"] == self.algorithm_var.get())
        self.current_result = selected
        self._display_result(selected, frame_count)
        self.footer_var.set("Comparison complete. The step table shows the currently selected algorithm.")

    def _display_result(self, result, frame_count):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for index, step in enumerate(result["steps"], start=1):
            frame_values = step["frames"] + ["—"] * (4 - len(step["frames"]))
            values = (
                index, step["page"], frame_values[0], frame_values[1],
                frame_values[2], frame_values[3], step["status"], step["replaced"]
            )
            self.tree.insert("", "end", values=values, tags=(step["status"],))
        total = len(result["steps"])
        hit_rate = (result["hits"] / total) * 100 if total else 0
        fault_rate = (result["faults"] / total) * 100 if total else 0
        self.faults_card.config(text=str(result["faults"]))
        self.hits_card.config(text=str(result["hits"]))
        self.hit_rate_card.config(text=f"{hit_rate:.1f}%")
        self.fault_rate_card.config(text=f"{fault_rate:.1f}%")
        self.root.title(f"CSE316 | {result['name']} Page Replacement Simulator")


if __name__ == "__main__":
    root = tk.Tk()
    app = PageReplacementApp(root)
    root.mainloop()
